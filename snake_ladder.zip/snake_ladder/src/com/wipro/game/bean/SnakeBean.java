package com.wipro.game.bean;

public class SnakeBean {
	private int headCell;
	private int tailCell;
	public int getHeadCell() {
		return headCell;
	}
	public void setHeadCell(int headCell) {
		this.headCell = headCell;
	}
	public int getTailCell() {
		return tailCell;
	}
	public void setTailCell(int tailCell) {
		this.tailCell = tailCell;
	}
	
}

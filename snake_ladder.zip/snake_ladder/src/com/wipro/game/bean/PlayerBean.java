package com.wipro.game.bean;

public class PlayerBean {
	private String firstPlayerID;
	private String secondPlayerID;
	public String getFirstPlayerID() {
		return firstPlayerID;
	}
	public void setFirstPlayerID(String firstPlayerID) {
		this.firstPlayerID = firstPlayerID;
	}
	public String getSecondPlayerID() {
		return secondPlayerID;
	}
	public void setSecondPlayerID(String secondPlayerID) {
		this.secondPlayerID = secondPlayerID;
	}

}

package com.wipro.game.bean;

public class LadderBean {
	private int topCell;
	private int bottomCell;
	public int getTopCell() {
		return topCell;
	}
	public void setTopCell(int topCell) {
		this.topCell = topCell;
	}
	public int getBottomCell() {
		return bottomCell;
	}
	public void setBottomCell(int bottomCell) {
		this.bottomCell = bottomCell;
	}
	
}

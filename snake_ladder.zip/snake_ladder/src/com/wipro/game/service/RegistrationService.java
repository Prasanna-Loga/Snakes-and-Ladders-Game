package com.wipro.game.service;

import com.wipro.game.bean.RegisterBean;
import com.wipro.game.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RegistrationService {
	Connection con=DBUtil.getDatabaseConnection();
	Statement stmt;
	ResultSet rs;
	public boolean generatePlayerID(RegisterBean rbean) {
		
		try {
			 
			stmt = con.createStatement();
			 //System.out.println("Creating statement...");
			String query="select PLAYER_ID_SEQ.nextval from dual";
			rs = stmt.executeQuery(query);
			rs.next();

			System.out.println(rs.getInt(1));
			rbean.setPlayerID("PL"+rs.getInt(1));
			
			if(rs!=null)
				return true;
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
		return false;
		
	}
	
	public boolean validatePlayerName(RegisterBean rbean) {
		
		if(rbean.getPlayerName()==null||rbean.getPlayerName().length()<2)
		return false;
		else
		{
			rbean.setPlayerName(rbean.getPlayerName().toUpperCase());
		return true;}
	}
	
	public String registerPlayer(RegisterBean rbean) {
		 if(rbean==null||rbean.getPlayerName()==null)
			 return "Inputs Missing";
		 else
		 {
			 
			 if(generatePlayerID(rbean)==true&&validatePlayerName(rbean)==true)
			 {
				 
					try {
						
						stmt = con.createStatement();
						 //System.out.println("22Creating statement...");
						PreparedStatement ps=con.prepareStatement("insert into GAMEPLAYERS values (?,?,?,?)");
						ps.setString(1,rbean.getPlayerID());
						ps.setString(2,rbean.getPlayerName());
						ps.setInt(3,0);
						ps.setInt(4,1);
						int rs=ps.executeUpdate();  
						System.out.println(rs+" records affected");
						if(rs>0)
						return "User Registered Successfully";
						else
							return "Registration Failed";
					}
					catch(SQLException e) {
						e.printStackTrace();
						}
			 }
			 else
				 return "�Invalid Inputs, Registration Failed";
		 }
		return null;
		
	}
	
}

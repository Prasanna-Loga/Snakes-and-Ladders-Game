package com.wipro.game.service;

import com.wipro.game.bean.LadderBean;
import com.wipro.game.bean.SnakeBean;
import com.wipro.game.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class AdminService {
	Connection con;
	Statement stmt;
	ResultSet rs;
	
	public boolean validateSnake(SnakeBean sbean) {
		if(sbean.getHeadCell()<sbean.getTailCell()||sbean.getHeadCell()==sbean.getTailCell()||(sbean.getHeadCell()<2&&sbean.getHeadCell()>99)||(sbean.getTailCell()<1&&sbean.getTailCell()>70))
		return false;
		else
		return true;
	}
	
	public boolean existingSnake(SnakeBean sbean) {
		
		try {
			 
			stmt = con.createStatement();
			 //System.out.println("Creating statement...");
			String query="select * from SNAKECELLS where SNAKEHEAD='"+sbean.getHeadCell()+"' AND SNAKETAIL='"+sbean.getTailCell()+"'";
			rs = stmt.executeQuery(query);
			if(rs.next())
				return false;
			else
				return true;
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
		return false;
		
	}
	
	public boolean isLadder(SnakeBean sbean) {
		
		try {
			 
			stmt = con.createStatement();
			 //System.out.println("Creating statement...");
			String query="select * from LADDERCELLS";
			rs = stmt.executeQuery(query);
			if(rs.next()) {
			
			if((sbean.getHeadCell()==rs.getInt(1)&&sbean.getHeadCell()==rs.getInt(2))||(sbean.getTailCell()==rs.getInt(1)&&sbean.getTailCell()==rs.getInt(2)))
				return false;
			else
				return true;
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
		return true;
		
	}
	
	public String makeSnakeEntry(SnakeBean sbean) {
		if(sbean==null) 
			return "Invalid Snake Design Request";
		else
		{
			if(validateSnake(sbean)==true&&isLadder(sbean)==true&&existingSnake(sbean)==true)
			{
				
				try {
					 
					stmt = con.createStatement();
					 //System.out.println("Creating statement...");
					PreparedStatement ps=con.prepareStatement("insert into SNAKECELLS values (?,?)");
					ps.setInt(1,sbean.getHeadCell());
					ps.setInt(2,sbean.getTailCell());
					int rs=ps.executeUpdate();  
					System.out.println(rs+" records affected");
					if(rs>0)
					return "New Entry Made";
					else
						return "Failed To Insert Snake";
				}
				catch(SQLException e) {
					e.printStackTrace();
					}
			}
			else
				return "Invalid Snake Design Request";
		}
		return null;
		
	}
	
	
	public boolean validateLadder(LadderBean lbean) {
		if(lbean.getTopCell()<lbean.getBottomCell()||lbean.getTopCell()==lbean.getBottomCell()||(lbean.getTopCell()<20&&lbean.getTopCell()>99)||(lbean.getBottomCell()<10&&lbean.getBottomCell()>70))
			return false;
			else
			return true;
		
	}
	
	public boolean existingLadder(LadderBean lbean) {
		
		try {
			 
			stmt = con.createStatement();
			 //System.out.println("Creating statement...");
			String query="select * from LADDERCELLS where LADDERTOP='"+lbean.getTopCell()+"' AND LADDERBOTTOM='"+lbean.getBottomCell()+"'";
			rs = stmt.executeQuery(query);
			if(rs.next())
				return false;
			else
				return true;
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
		return false;
		
	}
	
	public boolean isSnakeHeadOrTail(LadderBean lbean) {
		
		try {
			 
			stmt = con.createStatement();
			 //System.out.println("Creating statement...");
			String query="select * from LADDERCELLS";
			rs = stmt.executeQuery(query);
			if(rs.next()) {
			if((lbean.getTopCell()==rs.getInt(1)&&lbean.getTopCell()==rs.getInt(2))||(lbean.getBottomCell()==rs.getInt(1)&&lbean.getBottomCell()==rs.getInt(2)))
				return false;
			else
				return true;
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
		return true;
		
	}

	public String makeLadderEntry(LadderBean lbean) {
		if(lbean==null)
			return "�Invalid Ladder Design Request";
		else
		{
			if(validateLadder(lbean)==true&&isSnakeHeadOrTail(lbean)==true&&existingLadder(lbean)==true)
			{
				
				try {
					 
					stmt = con.createStatement();
					 //System.out.println("Creating statement...");
					PreparedStatement ps=con.prepareStatement("insert into LADDERCELLS values (?,?)");
					ps.setInt(1,lbean.getTopCell());
					ps.setInt(2,lbean.getBottomCell());
					int rs=ps.executeUpdate();  
					System.out.println(rs+" records affected");
					if(rs>0)
					return "New Entry Made";
					else
						return "Failed To Insert Ladder�";
				}
				catch(SQLException e) {
					e.printStackTrace();
					}
			}
			else
				return "Invalid Ladder Design Request";
		}
		return null;
	}
}

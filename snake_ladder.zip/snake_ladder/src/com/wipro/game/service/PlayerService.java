package com.wipro.game.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.wipro.game.util.DBUtil;


public class PlayerService {
	Connection con=DBUtil.getDatabaseConnection();
	Statement stmt;
	ResultSet rs;
	
	public boolean validatePlayer(String playerID) {
		
		try {
			 
			stmt = con.createStatement();
			 //System.out.println("Creating statement...");
			String query="select * from GAMEPLAYERS where PLAYERID='"+playerID+"'";
			rs = stmt.executeQuery(query);
			if(rs.next())
				return true;
			else
				return false;
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
		return false;
		
	}
	
	public int rollDice() {
		return (int)(Math.random() * (6) +1);
		
	}
	
	public boolean isSnake(int currentCell) {
		
		try {
			 
			stmt = con.createStatement();
			 //System.out.println("Creating statement...");
			String query="select * from SNAKECELLS where SNAKEHEAD='"+currentCell+"'";
			rs = stmt.executeQuery(query);
			if(rs.next())
				return true;
			else
				return false;
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
		return false;
		
	}
	
	public boolean isLadder(int currentCell) {
		
		try {
			 
			stmt = con.createStatement();
			 //System.out.println("Creating statement...");
			String query="select * from LADDERCELLS where LADDERBOTTOM='"+currentCell+"'";
			rs = stmt.executeQuery(query);
			if(rs.next())
				return true;
			else
				return false;
		}
		catch(SQLException e) {
			e.printStackTrace();
			}
		return false;
		
	}
	
	
		
					
	
	void play(String playerID,int a)
		{
					int roll=rollDice();
					System.out.println("Player "+playerID +" rolls dice and obtained "+roll);
					
						
					try {
						 
						stmt = con.createStatement();
						 //System.out.println("Creating statement...");
						String query="select CURRENTCELL from GAMEPLAYERS  where PLAYERID='"+playerID+"'";
						rs = stmt.executeQuery(query);
						rs.next();
						int oldCell=rs.getInt(1);
						int newCell=oldCell+roll;
						
							if(newCell<=100) {
							
									
									if(isSnake(newCell)==true) {
								
										String query1="select SNAKETAIL from SNAKECELLS where SNAKEHEAD='"+newCell+"'";
										rs = stmt.executeQuery(query1);
										rs.next();
										newCell=rs.getInt(1);
										System.out.println("Player "+playerID+" hits snake and reached the cell "+newCell);
										}
									
									
									else if(isLadder(newCell)==true) {
								
										String query1="select LADDERTOP from LADDERCELLS where LADDERBOTTOM='"+newCell+"'";
										rs = stmt.executeQuery(query1);
										rs.next();
										newCell=rs.getInt(1);
										System.out.println("Player "+playerID+" hits ladder and reached the cell "+newCell);
										}
							
									else {
										System.out.println("Player "+playerID+" moves from "+oldCell+" to the "+newCell);
										}
							
									String query1="update GAMEPLAYERS set CURRENTCELL='"+newCell+"' where PLAYERID='"+playerID+"'";
									int r=stmt.executeUpdate(query1);
									if(r>0);
							
									}
							else
								{
								System.out.println("Player"+a+": Invalid Movement!");
								}
							
					}
					
					catch(SQLException e) {
						e.printStackTrace();
						}
					catch(Exception e) {
						//e.printStackTrace();
					}
					
		}
					public void playGame(String playerOneID, String playerTwoID) 
					{
					if(validatePlayer(playerOneID)&&validatePlayer(playerTwoID)==false)
						System.out.println("Player Not Registered");
					else {
								do {
										play(playerOneID,1);
										
										
										
										
										try {
											 
											stmt = con.createStatement();
											 //System.out.println("Creating statement...");
											String query="select CURRENTCELL from GAMEPLAYERS  where PLAYERID='"+playerOneID+"'";
											rs = stmt.executeQuery(query);
											rs.next();
											int currentCell1=rs.getInt(1);
											
											//System.out.println(currentCell1+" "+currentCell2);
											
												if(currentCell1==100) {
													System.out.println("Player "+playerOneID+" wins the game");
												
												break;}
										}
										catch(SQLException e) {
											e.printStackTrace();
											}
										catch(Exception e) {
											//e.printStackTrace();
										}
										try {
											Thread.sleep(1000);
										} catch (InterruptedException e1) {
											// TODO Auto-generated catch block
											e1.printStackTrace();
										}
										play(playerTwoID,2);
										
										
										String query1="select CURRENTCELL from GAMEPLAYERS  where PLAYERID='"+playerTwoID+"'";
										try {
											rs = stmt.executeQuery(query1);
										
										rs.next();
										int currentCell2=rs.getInt(1);
											if(currentCell2==100) {
												System.out.println("Player "+playerTwoID+" wins the game");
											
											break;}
										}
										catch (SQLException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
										catch(Exception e) {
											//e.printStackTrace();
										}
										try {
											Thread.sleep(1000);
										} catch (InterruptedException e1) {
											// TODO Auto-generated catch block
											e1.printStackTrace();
										}
									}while(true);
							
						}	
					
					
					}
				
	
}

